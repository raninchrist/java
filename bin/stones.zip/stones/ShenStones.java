package stones;

public class ShenStones extends StonesPlayer{

    public ShenStones(String n) {
        super(n);
        //TODO Auto-generated constructor stub
    }

    public int myTurn(int stonesLeft) {
        return 1;
    }

}
